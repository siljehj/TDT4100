package oving7;

public interface ObservableListListener {
    
    public void listChanged(ObservableList list, int index);

}
